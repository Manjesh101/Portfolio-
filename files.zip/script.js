(function () {
  "use strict";

  // Mobile menu
  var burger = document.querySelector(".burger");
  var menu = document.getElementById("menu");
  function setMenu(open) {
    menu.classList.toggle("open", open);
    burger.setAttribute("aria-expanded", String(open));
  }
  burger.addEventListener("click", function () {
    setMenu(burger.getAttribute("aria-expanded") !== "true");
  });
  menu.addEventListener("click", function (e) {
    if (e.target.tagName === "A") setMenu(false);
  });

  // Typing effect for the JSON response in the hero
  var json = document.getElementById("json");
  var full = json.getAttribute("data-text");
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce) {
    json.textContent = full;
  } else {
    var i = 0;
    json.textContent = "";
    json.classList.add("typing");
    setTimeout(function type() {
      i += 2;
      json.textContent = full.slice(0, i);
      if (i < full.length) {
        setTimeout(type, 22);
      } else {
        json.classList.remove("typing");
      }
    }, 900);
  }

  // Copy email to clipboard
  var toast = document.getElementById("toast");
  document.getElementById("copy").addEventListener("click", function () {
    var email = "manjeshcse172@gmail.com";
    function done(msg) {
      toast.textContent = msg;
      setTimeout(function () { toast.textContent = ""; }, 2500);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(email).then(
        function () { done("Email address copied."); },
        function () { done("Copy failed. Email me at " + email); }
      );
    } else {
      done("Copy isn’t supported here. Email me at " + email);
    }
  });
})();
